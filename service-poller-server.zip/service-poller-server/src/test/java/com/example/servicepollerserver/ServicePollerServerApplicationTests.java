package com.example.servicepollerserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicePollerServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
