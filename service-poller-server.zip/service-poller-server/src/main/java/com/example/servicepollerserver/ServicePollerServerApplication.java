package com.example.servicepollerserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServicePollerServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServicePollerServerApplication.class, args);
	}

}
